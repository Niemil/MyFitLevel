// MyFitLevel widget for macOS (free app "Übersicht", https://tracesof.net/uebersicht/).
// Put the myfitlevel.widget folder in ~/Library/Application Support/Übersicht/widgets/ and edit the two lines below.
const KEY = "PASTE_YOUR_API_KEY_HERE"; // your MyFitLevel API key (Settings > API access)
const SD = false;
const BASE = SD ? "https://snakediet.org" : "https://myfitlevel.com";
const ACC = SD ? "#2bb3a3" : "#36a85c";

export const command = `curl -s --max-time 15 "${BASE}/api/v1/widget?key=${KEY}"`;
export const refreshFrequency = 300000; // every 5 minutes

export const className = `
  left: 40px; top: 40px; width: 340px; padding: 22px; border-radius: 22px; color: #fff;
  font-family: -apple-system, "SF Pro Text", sans-serif;
  background: linear-gradient(160deg, rgba(28,47,69,.92), rgba(15,27,42,.92));
  border: 1px solid rgba(255,255,255,.14); box-shadow: 0 16px 40px rgba(0,0,0,.35);
  .row { display: flex; justify-content: space-between; align-items: center; }
  .lv { font-size: 34px; font-weight: 700; color: ${ACC}; }
  .name { font-size: 15px; font-weight: 600; }
  .sub { font-size: 11px; opacity: .7; margin-top: 4px; }
  .bar { height: 9px; border-radius: 5px; background: rgba(255,255,255,.16); margin: 14px 0 4px; overflow: hidden; }
  .bar i { display: block; height: 100%; background: ${ACC}; border-radius: 5px; }
  .grid { display: flex; justify-content: space-between; margin-top: 14px; text-align: center; }
  .grid b { display: block; font-size: 22px; } .grid span { font-size: 10px; opacity: .7; text-transform: uppercase; letter-spacing: .06em; }
  .today { margin-top: 14px; font-size: 13px; color: ${ACC}; }
`;

export const render = ({ output }) => {
  let d;
  try { d = JSON.parse(output); } catch (e) { return <div>No data yet</div>; }
  if (!d.ok) return <div>{d.error}</div>;
  return (
    <div>
      <div className="row"><div className="lv">LV {d.level}</div><div className="name">{d.name}</div></div>
      <div className="bar"><i style={{ width: d.level_pct + "%" }} /></div>
      <div className="sub">{d.level_xp.toLocaleString()} / {d.level_need.toLocaleString()} to next level · {d.xp.toLocaleString()} {SD ? "KTN points" : "points"}</div>
      <div className="grid">
        <div><b>{d.streak}</b><span>Streak</span></div>
        {SD ? <div><b>{d.fast_hours}</b><span>Fasting h</span></div> : <div><b>{d.week_workouts}</b><span>This week</span></div>}
        <div><b>{d.week_points.toLocaleString()}</b><span>{SD ? "Week KTN" : "Week pts"}</span></div>
        {SD ? <div><b>{d.longest_fast_hours}</b><span>Longest h</span></div> : <div><b>{d.prs}</b><span>PRs</span></div>}
      </div>
      <div className="today">{SD ? "" : "Today: "}{d.today_label || d.today_routine}</div>
    </div>
  );
};
