[Variables]
; Edit these two lines, then right-click the skin > Refresh skin.
BaseURL=https://snakediet.org
ApiKey=PASTE_YOUR_API_KEY_HERE
; Colours (R,G,B,A)
Accent=43,179,163,255
Panel=18,30,46,235
Text=255,255,255,255
Muted=255,255,255,150
